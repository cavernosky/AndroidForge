# CAVER DJ STUDIO PRO 2.0
Android landscape WebView app source.

Included: full-screen landscape dual-deck interface, local audio loading, play/pause, cue return, 8-second loop, playback-rate pitch, volume controls and crossfader.

Prototype limitations: EQ sliders, jog wheels, waveforms and FX buttons are currently interface elements only. Real audio DSP effects, BPM detection/beatmatching, scratching and hot-cue banks are not implemented yet. Do not describe this as a finished professional DJ engine.

Build with Android Gradle Plugin 8.7.3 / Kotlin 2.0.21 / compile SDK 35.
