package com.caver.djstudio
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.view.View
import android.content.pm.ActivityInfo
class MainActivity : Activity() {
 private lateinit var web: WebView
 private var callback: ValueCallback<Array<Uri>>? = null
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
 window.decorView.systemUiVisibility=(View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
 web=WebView(this); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.allowFileAccess=true; web.settings.mediaPlaybackRequiresUserGesture=false
 web.webChromeClient=object:WebChromeClient(){ override fun onShowFileChooser(v:WebView?, cb:ValueCallback<Array<Uri>>?, p:FileChooserParams?):Boolean { callback?.onReceiveValue(null); callback=cb; startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE},77); return true } }
 web.webViewClient=WebViewClient(); setContentView(web); web.loadUrl("file:///android_asset/index.html") }
 @Deprecated("Deprecated") override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==77){callback?.onReceiveValue(if(resultCode==RESULT_OK&&data?.data!=null) arrayOf(data.data!!) else null);callback=null}}
}
