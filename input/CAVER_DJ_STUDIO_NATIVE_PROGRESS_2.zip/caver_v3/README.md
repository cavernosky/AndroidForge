# CAVER DJ STUDIO — Android project v3.0

## Estado de esta entrega
Este archivo es un proyecto fuente Android Studio, NO un APK ya compilado. El entorno de creación disponible no tiene Android SDK ni Gradle instalado, por lo que no es posible compilar ni verificar un APK instalable aquí. No se debe instalar un archivo con extensión APK que no haya sido compilado y probado.

## Identidad
- Nombre: CAVER DJ STUDIO
- Application ID: `com.caver.djstudio`
- Versión: 3.0
- Android mínimo: API 26
- Compile/Target SDK: 35
- Kotlin + Jetpack Compose + AndroidX Media3

## Funciones que sí están implementadas
- Dos reproductores independientes Deck A y Deck B.
- Selección de archivos de audio locales mediante Android Storage Access Framework.
- Play/pausa y stop por deck.
- Crossfader con mezcla de volumen entre decks.
- Volumen independiente por deck.
- Ajuste de velocidad/pitch por deck.
- Biblioteca básica de carga.
- Academia con lecciones introductorias.

## Funciones profesionales que todavía NO están implementadas
- Análisis automático de BPM y beatgrid.
- SYNC/beatmatching real.
- Hot cues, loops, cue/preescucha por salida separada.
- EQ real de tres bandas, filtros y efectos DSP.
- Waveforms calculadas desde el audio.
- Grabación y exportación de mezclas.
- Academia audiovisual y seguimiento del progreso.

Los sliders/indicadores de BASS y la forma de onda en la interfaz de esta base son visuales/demostrativos; no deben interpretarse como procesamiento de audio real. Esta base no debe anunciarse como una consola profesional terminada.

## Cómo compilar un APK debug
1. En una computadora, instala Android Studio reciente con Android SDK Platform 35 y JDK 17.
2. Descomprime este proyecto.
3. Abre la carpeta `CAVER_DJ_STUDIO` en Android Studio.
4. Espera a que termine Gradle Sync.
5. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. El APK debug se genera normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

Para una versión de distribución se debe generar un APK firmado desde **Build > Generate Signed Bundle / APK**, proteger la clave privada y probar la app en varios teléfonos Android.

## Próxima etapa técnica
Para alcanzar calidad de producto DJ se requiere diseñar e integrar un motor de audio de baja latencia con mezcla de dos canales, EQ y FX DSP por deck, análisis BPM/beatgrid, SYNC, cue/loops, monitorización y grabación. Luego hay que medir latencia, evitar clipping y probar compatibilidad con dispositivos y formatos reales.
