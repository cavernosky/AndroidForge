# CAVER DJ STUDIO — plan y estado real

## Implementado en esta iteración
- Dos instancias independientes de Media3 ExoPlayer.
- Carga local de audio mediante selector Android.
- Play/pausa, stop, volumen por deck, pitch por deck y crossfader.
- Hot Cue básico por deck y loop fijo de 8 segundos.
- Barra de búsqueda conectada a la posición y duración reales de reproducción.
- Interfaz horizontal y sección de lecciones DJ Academy.

## Pendiente para una versión profesional
- Motor DSP por deck y mezcla con reloj de audio común.
- EQ LOW/MID/HIGH real y filtros.
- Echo, Reverb, Flanger, Delay, Brake y Bitcrush audibles.
- Análisis BPM, beatgrid, SYNC y corrección de fase.
- Waveform calculada desde el audio, no decorativa.
- Hot cues múltiples, loops configurables, preescucha y grabación.

## Verificación
Este entorno no dispone de Android SDK/Gradle instalado, por lo que esta iteración no se declara compilada ni probada en un teléfono. Cada módulo pendiente debe verificarse con audio real antes de considerarse terminado.
