package com.caver.djstudio

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private val Bg = Color(0xFF090D18)
private val Panel = Color(0xFF151D2D)
private val Accent = Color(0xFF22D3EE)
private val Purple = Color(0xFFA78BFA)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DJMixApp() }
    }
}

@Composable
fun DJMixApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val deckA = remember { ExoPlayer.Builder(context).build() }
    val deckB = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) {
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
        deckA.setAudioAttributes(attrs, false)
        deckB.setAudioAttributes(attrs, false)
        onDispose { deckA.release(); deckB.release() }
    }

    var tab by remember { mutableStateOf(0) }
    var titleA by remember { mutableStateOf("Carga una canción") }
    var titleB by remember { mutableStateOf("Carga una canción") }
    var crossfader by remember { mutableFloatStateOf(0.5f) }
    var volumeA by remember { mutableFloatStateOf(1f) }
    var volumeB by remember { mutableFloatStateOf(1f) }
    var pitchA by remember { mutableFloatStateOf(1f) }
    var pitchB by remember { mutableFloatStateOf(1f) }
    var bassA by remember { mutableFloatStateOf(0f) }
    var bassB by remember { mutableFloatStateOf(0f) }
    var cueA by remember { mutableLongStateOf(0L) }
    var cueB by remember { mutableLongStateOf(0L) }
    var loopA by remember { mutableStateOf(false) }
    var loopB by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("CAVER DJ STUDIO listo") }
    var positionA by remember { mutableLongStateOf(0L) }
    var positionB by remember { mutableLongStateOf(0L) }
    var durationA by remember { mutableLongStateOf(0L) }
    var durationB by remember { mutableLongStateOf(0L) }

    fun updateVolumes() {
        deckA.volume = volumeA * (1f - crossfader)
        deckB.volume = volumeB * crossfader
        deckA.setPlaybackSpeed(pitchA)
        deckB.setPlaybackSpeed(pitchB)
    }

    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            deckA.setMediaItem(MediaItem.fromUri(it)); deckA.prepare()
            titleA = displayName(context, it); status = "Deck A cargado"
        }
    }
    val pickB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            deckB.setMediaItem(MediaItem.fromUri(it)); deckB.prepare()
            titleB = displayName(context, it); status = "Deck B cargado"
        }
    }

    LaunchedEffect(crossfader, volumeA, volumeB, pitchA, pitchB) { updateVolumes() }
    LaunchedEffect(loopA, loopB) {
        while (true) {
            positionA = deckA.currentPosition.coerceAtLeast(0L)
            positionB = deckB.currentPosition.coerceAtLeast(0L)
            durationA = deckA.duration.takeIf { it > 0L } ?: 0L
            durationB = deckB.duration.takeIf { it > 0L } ?: 0L
            if (loopA && deckA.duration > 0 && deckA.currentPosition >= minOf(cueA + 8000L, deckA.duration)) deckA.seekTo(cueA)
            if (loopB && deckB.duration > 0 && deckB.currentPosition >= minOf(cueB + 8000L, deckB.duration)) deckB.seekTo(cueB)
            delay(100)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, secondary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Album, null) }, label = { Text("Mixer") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Mi música") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.School, null) }, label = { Text("Aprender") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("CAVER DJ STUDIO", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Text("PROFESSIONAL DJ MIXING SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
                    }
                    Surface(color = Color(0xFF12313D), shape = RoundedCornerShape(50)) {
                        Text("● LIVE", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                when (tab) {
                    0 -> MixerScreen(
                        titleA, titleB, status, crossfader, volumeA, volumeB, pitchA, pitchB,
                        bassA, bassB, cueA, cueB, loopA, loopB,
                        positionA, positionB, durationA, durationB,
                        onCueA = { cueA = deckA.currentPosition; status = "HOT CUE A guardado" },
                        onCueB = { cueB = deckB.currentPosition; status = "HOT CUE B guardado" },
                        onRecallA = { deckA.seekTo(cueA); status = "CUE A" },
                        onRecallB = { deckB.seekTo(cueB); status = "CUE B" },
                        onLoopA = { loopA = !loopA; status = if (loopA) "LOOP A de 8 segundos activado" else "LOOP A desactivado" },
                        onLoopB = { loopB = !loopB; status = if (loopB) "LOOP B de 8 segundos activado" else "LOOP B desactivado" },
                        onLoadA = { pickA.launch(arrayOf("audio/*")) },
                        onLoadB = { pickB.launch(arrayOf("audio/*")) },
                        onPlayA = { if (deckA.isPlaying) deckA.pause() else deckA.play() },
                        onPlayB = { if (deckB.isPlaying) deckB.pause() else deckB.play() },
                        onStopA = { deckA.pause(); deckA.seekTo(0) },
                        onStopB = { deckB.pause(); deckB.seekTo(0) },
                        onCross = { crossfader = it },
                        onVolA = { volumeA = it }, onVolB = { volumeB = it },
                        onPitchA = { pitchA = it }, onPitchB = { pitchB = it },
                        onBassA = { bassA = it }, onBassB = { bassB = it },
                        onSeekA = { deckA.seekTo(it) }, onSeekB = { deckB.seekTo(it) }
                    )
                    1 -> LibraryScreen(titleA, titleB, onA = { pickA.launch(arrayOf("audio/*")) }, onB = { pickB.launch(arrayOf("audio/*")) })
                    else -> LearnScreen()
                }
            }
        }
    }
}

@Composable
private fun MixerScreen(
    titleA: String, titleB: String, status: String,
    cross: Float, volA: Float, volB: Float, pitchA: Float, pitchB: Float,
    bassA: Float, bassB: Float, cueA: Long, cueB: Long, loopA: Boolean, loopB: Boolean,
    positionA: Long, positionB: Long, durationA: Long, durationB: Long,
    onCueA: () -> Unit, onCueB: () -> Unit, onRecallA: () -> Unit, onRecallB: () -> Unit,
    onLoopA: () -> Unit, onLoopB: () -> Unit,
    onLoadA: () -> Unit, onLoadB: () -> Unit,
    onPlayA: () -> Unit, onPlayB: () -> Unit, onStopA: () -> Unit, onStopB: () -> Unit,
    onCross: (Float) -> Unit, onVolA: (Float) -> Unit, onVolB: (Float) -> Unit,
    onPitchA: (Float) -> Unit, onPitchB: (Float) -> Unit,
    onBassA: (Float) -> Unit, onBassB: (Float) -> Unit,
    onSeekA: (Long) -> Unit, onSeekB: (Long) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
        item { DeckCard("DECK A", titleA, Accent, volA, pitchA, bassA, cueA, loopA, positionA, durationA, onLoadA, onPlayA, onStopA, onVolA, onPitchA, onBassA, onCueA, onRecallA, onLoopA, onSeekA) }
        item { DeckCard("DECK B", titleB, Purple, volB, pitchB, bassB, cueB, loopB, positionB, durationB, onLoadB, onPlayB, onStopB, onVolB, onPitchB, onBassB, onCueB, onRecallB, onLoopB, onSeekB) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("CROSSFADER", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("A", color = Accent, fontWeight = FontWeight.Bold)
                        Text("B", color = Purple, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = cross, onValueChange = onCross, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Accent, inactiveTrackColor = Purple))
                    Text(status, color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun DeckCard(
    label: String, title: String, tint: Color, volume: Float, pitch: Float, bass: Float,
    cue: Long, loop: Boolean, position: Long, duration: Long,
    onLoad: () -> Unit, onPlay: () -> Unit, onStop: () -> Unit,
    onVolume: (Float) -> Unit, onPitch: (Float) -> Unit, onBass: (Float) -> Unit,
    onSaveCue: () -> Unit, onRecallCue: () -> Unit, onLoop: () -> Unit, onSeek: (Long) -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = tint, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                Text("● READY", color = Color(0xFF86EFAC), fontSize = 10.sp)
            }
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
            // Seek bar connected to the actual Media3 playback position.
            Slider(
                value = if (duration > 0L) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                onValueChange = { if (duration > 0L) onSeek(it.toLong()) },
                valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                enabled = duration > 0L,
                colors = SliderDefaults.colors(thumbColor = tint, activeTrackColor = tint)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(position), color = Muted, fontSize = 10.sp)
                Text(formatTime(duration), color = Muted, fontSize = 10.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onLoad, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = tint, contentColor = Bg)) {
                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(5.dp)); Text("Cargar")
                }
                FilledTonalIconButton(onClick = onPlay) { Icon(Icons.Default.PlayArrow, "Play / pausa") }
                FilledTonalIconButton(onClick = onStop) { Icon(Icons.Default.Stop, "Detener") }
            }
            SliderLine("VOL", volume, onVolume)
            SliderLine("PITCH", (pitch - .9f) / .2f, { onPitch(.9f + it * .2f) }, valueText = "${((pitch - 1f) * 100).toInt()}%")
            SliderLine("BASS", (bass + 1f) / 2f, { onBass(it * 2f - 1f) }, valueText = "${(bass * 100).toInt()}%")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = onSaveCue, modifier = Modifier.weight(1f)) { Text("SET CUE") }
                OutlinedButton(onClick = onRecallCue, modifier = Modifier.weight(1f)) { Text("RETURN") }
                Button(onClick = onLoop, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (loop) tint else Panel)) { Text(if (loop) "8s LOOP ON" else "8s LOOP") }
            }
            Text("Cue guardado: ${(cue / 1000)} s · Pitch y transporte activos", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SliderLine(label: String, value: Float, onChange: (Float) -> Unit, valueText: String = "${(value * 100).toInt()}%") {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 10.sp, modifier = Modifier.width(48.dp), fontWeight = FontWeight.Bold)
        Slider(value = value.coerceIn(0f, 1f), onValueChange = onChange, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
        Text(valueText, color = Color.White, fontSize = 10.sp, modifier = Modifier.width(38.dp))
    }
}

@Composable
private fun LibraryScreen(titleA: String, titleB: String, onA: () -> Unit, onB: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("MUSIC LIBRARY", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Selecciona archivos de audio guardados en tu Android. No se suben a internet.", color = Muted)
        LibraryTrack(titleA, "CARGAR EN DECK A", Accent, onA)
        LibraryTrack(titleB, "CARGAR EN DECK B", Purple, onB)
        Text("Formatos disponibles: los que Android pueda reproducir mediante Media3 (por ejemplo MP3, AAC, WAV y FLAC, según el dispositivo).", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun LibraryTrack(name: String, action: String, color: Color, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MusicNote, null, tint = color, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Color.White, maxLines = 1, fontWeight = FontWeight.SemiBold)
                Text(action, color = color, fontSize = 10.sp)
            }
            IconButton(onClick = onClick) { Icon(Icons.Default.AddCircle, null, tint = color) }
        }
    }
}

@Composable
private fun LearnScreen() {
    val lessons = listOf(
        "01  Conoce tu consola" to "Identifica los dos decks, play, cue, volumen, pitch y crossfader. Practica cada control sin música.",
        "02  Ritmo y BPM" to "BPM significa beats por minuto. Cuenta 1-2-3-4 siguiendo el pulso y aprende a reconocer el tempo.",
        "03  Igualar el tempo" to "Ajusta la velocidad de la segunda canción para acercar sus BPM. Escucha si los golpes coinciden.",
        "04  Usa el crossfader" to "Mueve el control lentamente de A hacia B. Evita cambios bruscos y escucha cómo se mezclan.",
        "05  Transiciones básicas" to "Empieza la segunda canción en una frase musical nueva. Haz el cambio poco a poco durante varios compases.",
        "06  Ecualización" to "Reduce graves en una pista antes de subir los graves de la otra. Evita que ambas compitan por el mismo espacio.",
        "07  Tu primera mezcla" to "Elige dos canciones con BPM parecido, prepara la segunda, iguala el ritmo y realiza una transición de 30 segundos."
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Text("CAVER DJ ACADEMY", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Aprende a tu ritmo, una lección a la vez.", color = Muted)
        }
        items(lessons.size) { index ->
            var expanded by remember { mutableStateOf(index == 0) }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), onClick = { expanded = !expanded }) {
                Column(Modifier.fillMaxWidth().padding(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(lessons[index].first, color = if (index % 2 == 0) Accent else Purple, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = Muted)
                    }
                    if (expanded) {
                        Spacer(Modifier.height(8.dp))
                        Text(lessons[index].second, color = Color(0xFFD6DEEA), fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
        }
    }
}

private fun displayName(context: android.content.Context, uri: Uri): String {
    var name = "Pista seleccionada"
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
    }
    return name
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    return "%d:%02d".format(total / 60, total % 60)
}
