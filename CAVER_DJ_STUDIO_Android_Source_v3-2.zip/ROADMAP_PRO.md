# CAVER DJ STUDIO — plan de producto profesional

## Audio core
- Motor de audio de baja latencia, con reloj común y sincronización de decks.
- Mezcla de dos canales con curva de crossfader configurable.
- Ganancia, medidores peak/RMS y protección contra clipping.
- EQ de 3 bandas y filtros implementados en DSP por canal.
- Efectos temporizados al beat: echo, reverb, flanger y filter.

## Herramientas DJ
- BPM, beatgrid y detección de downbeat.
- Beatmatch manual y SYNC con corrección de fase.
- Cue, hot cues, loops, quantize y búsqueda por waveform real.
- Preescucha/CUE con salida compatible y configuración de audio.

## Biblioteca y grabación
- Metadatos, análisis de archivos, playlists, búsqueda e historial.
- Grabación estéreo de la mezcla y exportación WAV/AAC.
- Recuperación ante llamadas, desconexiones y cambios de audio focus.

## QA antes de publicar
- Pruebas en teléfonos Android de varias marcas y versiones.
- Pruebas de latencia, estabilidad, consumo, temperatura y audio focus.
- Pruebas con formatos, archivos largos, cambios de pista y reproducción simultánea.
- Firma de release, política de privacidad y revisión de permisos.

Una interfaz con controles dibujados no equivale a un efecto de audio funcional. Cada módulo se considera terminado solo después de implementarlo en el motor y validarlo escuchando y midiendo el audio.
